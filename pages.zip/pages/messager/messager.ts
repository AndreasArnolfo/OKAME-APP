import { Component } from '@angular/core';

@Component({
  selector: 'page-messager',
  templateUrl: 'messager.html'
})
export class MessagerPage {

}
