import { Component } from '@angular/core';

@Component({
  selector: 'page-profilPlus',
  templateUrl: 'profilPlus.html'
})
export class ProfilPlusPage {

}
